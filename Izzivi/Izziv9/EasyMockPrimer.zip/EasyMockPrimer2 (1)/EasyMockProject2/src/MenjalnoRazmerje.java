

import java.io.*;

public interface MenjalnoRazmerje {
    double getRazmerje(String vhodnaValuta, String izhodnaValuta) throws IOException;
}
