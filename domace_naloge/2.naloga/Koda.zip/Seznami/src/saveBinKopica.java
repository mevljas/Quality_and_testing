

import java.io.*;

public interface saveBinKopica {
    void save(OutputStream outputStream) throws OutOfMemoryError;
}
